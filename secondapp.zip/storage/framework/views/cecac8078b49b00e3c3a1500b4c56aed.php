

<?php $__env->startSection('content'); ?>
<div class="container box">
   <h3 align="center">Simple  Admin Signup</h3><br />
   
   <form method="POST" action='<?php echo e(route('myadmin.delete')); ?>' enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
   <div class="form-group">
     <label>Enter Name</label>
     <input type="name" name="name" class="form-control" />
    </div>
    <div class="form-group">
     <label>Enter Password</label>
     <input type="password" name="password" class="form-control" />
    </div>
    <div class="form-group">
     <input type="submit" name="Delete" class="btn btn-primary" value="Delete" />
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\pc 1\Desktop\secondapp\resources\views/delete.blade.php ENDPATH**/ ?>